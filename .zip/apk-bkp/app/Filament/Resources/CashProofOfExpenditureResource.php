<?php

namespace App\Filament\Resources;

use Filament\Forms\Form;
use Filament\Tables\Table;
use Filament\Resources\Resource;
use Filament\Forms\Components\Select;
use App\Models\CashProofOfExpenditure;
use Filament\Forms\Components\Textarea;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\ViewAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Forms\Components\TextInput;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TrashedFilter;
use Riskihajar\Terbilang\Facades\Terbilang;
use Filament\Tables\Actions\BulkActionGroup;
use Filament\Tables\Actions\DeleteBulkAction;
use App\Filament\Resources\CashProofOfExpenditureResource\Pages;

class CashProofOfExpenditureResource extends Resource
{
    protected static ?string $model = CashProofOfExpenditure::class;
    protected static ?string $navigationIcon = 'heroicon-o-banknotes';
    protected static ?string $navigationLabel = 'BKP';
    protected static ?string $modelLabel = 'Bukti Kas Pengeluaran';
    protected static ?string $pluralModelLabel = 'Daftar BKP'; // <-- Judul di halaman utama resource


    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Select::make('school_id')
                    ->relationship('school', 'school_name')
                    ->label('Sekolah')
                    ->searchable()
                    ->preload()
                    ->required(),
                Select::make('activity_id')
                    ->relationship('activity', 'activity_name')
                    ->label('Kegiatan')
                    ->searchable()
                    ->preload()
                    ->required(),
                TextInput::make('nominal')
                    ->numeric()
                    ->required()
                    ->prefix('Rp')
                    ->live(onBlur: true)
                    ->afterStateUpdated(function ($state, callable $set) {
                        if (is_numeric($state)) {
                            // Langkah 2: Ganti pemanggilan fungsi dengan Facade
                            $terbilangText = ucwords(Terbilang::make($state)) . ' Rupiah';
                            $set('sorted', $terbilangText);
                        } else {
                            $set('sorted', '');
                        }
                    }),
                Textarea::make('sorted')
                    ->label('Terbilang')
                    ->disabled()
                    ->required(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('school.school_name')->label('Sekolah')->searchable()->sortable(),
                TextColumn::make('activity.activity_name')->label('Kegiatan')->searchable(),
                TextColumn::make('nominal')->money('IDR')->sortable(),
                TextColumn::make('created_at')->label('Tanggal Dibuat')->dateTime('d-M-Y')->sortable(),
            ])
            ->filters([
                TrashedFilter::make(),
                SelectFilter::make('school')->relationship('school', 'school_name'),
                SelectFilter::make('activity')->relationship('activity', 'activity_name'),
            ])
            ->actions([
                ViewAction::make(),
                EditAction::make(),
            ])
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListCashProofOfExpenditures::route('/'),
            'create' => Pages\CreateCashProofOfExpenditure::route('/create'),
            'view' => Pages\ViewCashProofOfExpenditure::route('/{record}'),
            'edit' => Pages\EditCashProofOfExpenditure::route('/{record}/edit'),
        ];
    }
}
